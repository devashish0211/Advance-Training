package repeating_element;

import java.util.*;

public class FirstRepeatingElement {

	static void printFirstRepeating(int arr[]) {

		int min = -1;

		HashSet<Integer> set = new HashSet<>();

		for (int i = arr.length - 1; i >= 0; i--) {

			if (set.contains(arr[i]))
				min = i;

			else
				set.add(arr[i]);
		}

		if (min != -1)
			System.out.println("\nThe first repeating element from above array is:- \n" + arr[min]+"\n");
		else
			System.out.println("\nThere are no repeating elements"+"\n");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[] = { 1, 2, 3, 10, 4, 4, 5, 7, 8 };
		System.out.println("First list:- ");
		for (int element: arr) {
            System.out.println(element);
        }
		printFirstRepeating(arr);
		

		int arr1[] = { 1, 2, 3, 10, 6, 4, 10, 7, 10 };
		System.out.println("Second list:- ");
		for (int element: arr1) {
            System.out.println(element);
        }
		printFirstRepeating(arr1);
	}

}

package checking_balanced_brackets;
import java.util.*;

public class CheckBalancedBrackets {

	static boolean areBracketsBalanced(String expr) {

		Deque<Character> stack = new ArrayDeque<Character>();

		for (int i = 0; i < expr.length(); i++) {
			char x = expr.charAt(i);

			if (x == '(' || x == '[' || x == '{') {

				stack.push(x);
				continue;
			}

			if (stack.isEmpty())
				return false;
			char check;
			switch (x) {
			case ')':
				check = stack.pop();
				if (check == '{' || check == '[')
					return false;
				break;

			case '}':
				check = stack.pop();
				if (check == '(' || check == '[')
					return false;
				break;

			case ']':
				check = stack.pop();
				if (check == '(' || check == '{')
					return false;
				break;
			}
		}

		return (stack.isEmpty());
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println("Entered Brackets are:-");
		String expr = "[()]{}{[()()]()}";
		System.out.println(expr);
		if (areBracketsBalanced(expr))
			System.out.println("\nBalanced ");
		else
			System.out.println("\nNot Balanced ");
		System.out.println("\n****************************");
		System.out.println("\nEntered Brackets are:-");
		String expr1 = "[(])}";
		System.out.println(expr1);
		if (areBracketsBalanced(expr1))
			System.out.println("\nBalanced ");
		else
			System.out.println("\nNot Balanced ");
	}

}

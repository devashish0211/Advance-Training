package com.rectangle;

import java.util.Scanner;
public class Rectangle {

	    int length; 
	    int breadth; 
	    int area; 
	   
	    public Rectangle()
	    {
	    	length = 0;
	    	breadth= 0;
	    }

	    void input() 
	    {
	        Scanner in = new Scanner(System.in);
	        System.out.print("Enter the length of rectangle:- ");
	        length = in.nextInt();
	        System.out.print("Enter breadth of rectangle:- ");
	        breadth = in.nextInt();
	    }

	    void rec_area() 
	    {
	        area = length * breadth;
	        
	    }

	    void display() 
	    {
	        System.out.println("Area of Rectangle = " + area);
	       
	    }
	    
	    
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		Rectangle rec1 = new Rectangle();
        rec1.input();
        rec1.rec_area();
        rec1.display();
        System.out.println("****************************");
        Rectangle rec2 = new Rectangle();
        rec2.input();
        rec2.rec_area();
        rec2.display();
        System.out.println("****************************");
        Rectangle rec3 = new Rectangle();
        rec3.input();
        rec3.rec_area();
        rec3.display();
        System.out.println("****************************");
        Rectangle rec4 = new Rectangle();
        rec4.input();
        rec4.rec_area();
        rec4.display();
        System.out.println("****************************");
        Rectangle rec5 = new Rectangle();
        rec5.input();
        rec5.rec_area();
        rec5.display();
	}

}
package multithreading;
import java.lang.Runnable;

public class Storage {
	private int x;

	public Storage(int X) {
		x = X;
	}

	public int GetX() {
		return (x);
	}

	public Storage(Storage s) {
		this.x = s.GetX();
	}
}
class Printer implements Runnable

{
	private Storage Storage;
	Printer(Storage s) {
		Storage = new Storage(s);
	}

	public void run()
	{
		System.out.println(Storage.GetX());
	}

}

class Counter implements Runnable

{
	private int N;
	public Counter(int n) {
		N = n;
	}

	public int GetN() {
		return (N);
	}

	public void run()
	{
		for (int iLoop = 1; iLoop <= N; iLoop++)
		{
			Storage Storage = new Storage(iLoop);
			Printer printer = new Printer(Storage);
			Thread.yield();
			printer.run();
		}
	}
}


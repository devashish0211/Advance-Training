package multithreading;

public class ThreadCounter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Counter counter = new Counter(25);
		counter.run();
	}

}

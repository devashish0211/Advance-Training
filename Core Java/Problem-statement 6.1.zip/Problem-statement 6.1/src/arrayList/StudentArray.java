package arrayList;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class StudentArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String> a1 = new ArrayList<String>();
	    int n;
	    Scanner sc = new Scanner(System.in);
	    System.out.println("Enter the number of students you want to add:");
	    n = sc.nextInt();
	    System.out.println("\nEnter the name of the student:");
	    for (int i = 0; i < n; i++) {
	      a1.add(sc.next());
	    }
	
	    for (String a : a1) {
	      System.out.println("\nEnter the name of the student to be searched:");
	      String st = sc.next();
	      int position = Collections.binarySearch(a1, st);
	      System.out.println("posistion of " + st + " is: " + position);

	    }
	}

}

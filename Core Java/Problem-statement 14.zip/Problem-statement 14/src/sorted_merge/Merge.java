
package sorted_merge;

import java.util.*;

public class Merge {

	public static void sortedMerge(int a[], int b[], int res[], int n, int m) {

		Arrays.sort(a);
		Arrays.sort(b);

		int i = 0, j = 0, k = 0;
		while (i < n && j < m) {
			if (a[i] <= b[j]) {
				res[k] = a[i];
				i += 1;
				k += 1;
			} else {
				res[k] = b[j];
				j += 1;
				k += 1;
			}
		}

		while (i < n) {
			res[k] = a[i];
			i += 1;
			k += 1;
		}
		while (j < m) {
			res[k] = b[j];
			j += 1;
			k += 1;
		}
		
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[] = { 10, 5, 15 };
		int b[] = { 20, 3, 2 };
		int n = a.length;
		int m = b.length;

		// Final merge list
		int res[] = new int[n + m];
		System.out.println("Elements of 1st Array are:-");
		for (int element: a) {
            System.out.println(element);
        }
		System.out.println("\nElements of 2nd Array are:-");
		for (int element: b) {
            System.out.println(element);
        }
		sortedMerge(a, b, res, n, m);
		
		

		System.out.print("\nSorted merged list of 1st & 2nd is:\n");
		for (int i = 0; i < n + m; i++)
			System.out.print(" "+ res[i]);
		{
			int c[] = { 1, 16, 5, 15 };
			int d[] = { 20, 0, 2 };
			int n1 = c.length;
			int m1 = d.length;

			// Final merge list
			int res1[] = new int[n1 + m1];
			sortedMerge(c, d, res1, n1, m1);
			System.out.println("\n\n\nElements of 3rd Array are:-");
			for (int element: c) {
	            System.out.println(element);
	        }
			System.out.println("\nElements of 4th Array are:-");
			for (int element: d) {
	            System.out.println(element);
	        }
			System.out.print("\nSorted merged list of 3rd & 4th is :\n");
			for (int i = 0; i < n1 + m1; i++)
				System.out.print(" " + res1[i]);
		}

	}
}

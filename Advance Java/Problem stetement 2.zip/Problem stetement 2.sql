CREATE DATABASE   ShoppingCartBookstore;
USE ShoppingCartBookstore;


CREATE TABLE `Books`(
  `Book_Id`     VARCHAR(10) NOT NULL,
  `Book_name`   VARCHAR(50) NOT NULL,
  `Author`      VARCHAR(20) NOT NULL,
  `Price`       DOUBLE NOT NULL, 
   CONSTRAINT pk1 PRIMARY KEY (Book_id) 
);
select * from   `books`;
 

CREATE TABLE `order_details`(
  `Order_Id`     INT(10) NOT NULL,
  `Book_Id`      VARCHAR(20) NOT NULL,
  `Cust_Name`    VARCHAR(20) NOT NULL,
  `Phone_No`     INT(10) NOT NULL,
  `Address`      VARCHAR(50) NOT NULL,
  `Order_Date`   DATE NOT NULL,
  `Quantity`     iNT(10) NOT NULL,
   constraint pk1 primary key (Order_Id) ,
   constraint fk1 foreign key (Book_Id) 
   references books (Book_id) ) ;
   select * from   `order_details`;
   
   
   CREATE TABLE `Users` (
  `first_name`   VARCHAR(10) NOT NULL,
  `address`      VARCHAR(50) NOT NULL,
  `email`        VARCHAR(50) NOT NULL,
  `user_name`    VARCHAR(20) NOT NULL,
  `password`     VARCHAR(20) NOT NULL,
  `registration_date` DATE NOT NULL
);
select * from Users ;


   